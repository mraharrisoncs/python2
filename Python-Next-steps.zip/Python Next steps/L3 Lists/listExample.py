# Part 1 - Creating & Reading Lists

highscore = [125,63,35,12]
print(highscore)
print(highscore[0])
print(highscore[1])

input("\nPress ENTER to continue the program\n")

# Part 2 - Updating lists

highscore[0] = 127

print(highscore)

input("\nPress ENTER to continue the program\n")

# Part 3 - Appending lists

highscore.append(8)

print(highscore)

input("\nPress ENTER to continue the program\n")
