highscore = [125,63,35,12]
for counter in range(4):
    print(highscore[counter])
