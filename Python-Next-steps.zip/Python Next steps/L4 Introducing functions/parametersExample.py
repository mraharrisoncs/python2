def printDouble(amount):
    print("Double",amount,"is",amount*2)

printDouble(10)
printDouble(50)
printDouble(1862)
