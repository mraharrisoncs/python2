for counter in range(11):
    print(counter)


for counter in range(26):
    print(counter)

input("\nPress ENTER to exit program")
