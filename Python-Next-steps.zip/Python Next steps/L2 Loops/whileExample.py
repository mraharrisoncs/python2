counter = 1

while counter < 10:
    print("This line of code has been run",counter,"times")
    counter = counter + 1


input("\nPress ENTER to exit program")

