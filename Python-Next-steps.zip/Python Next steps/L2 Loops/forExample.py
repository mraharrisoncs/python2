for counter in range(10):
    print(counter)

input("\nPress ENTER to exit program")
