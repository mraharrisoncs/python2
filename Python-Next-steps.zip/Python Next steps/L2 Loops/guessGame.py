answer = "8"
guess = input("Guess a number: ")

# while() loop code goes here










# while() loop code ends

print("\nWell done, that's right!")

input("\nPress ENTER to exit program")

# EXTENSION ACTIVITY

# 1. Let the user put in the answer first (so it's not always 8)

# 2. Use a counter to count how many guesses it took to get the right answer
