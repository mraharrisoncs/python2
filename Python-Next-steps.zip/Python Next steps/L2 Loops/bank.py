pocketMoney = 0.01

for week in range(1,30):
    pocketMoney = pocketMoney * 2
    print("In week",week,"you will get £",pocketMoney)
    


