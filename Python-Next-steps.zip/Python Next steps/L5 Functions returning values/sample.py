def calcDouble(amount):
    amount = 2 * amount
    return amount

question = 120
answer = calcDouble(question)
print("Double",question,"is",answer)
