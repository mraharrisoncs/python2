age = int(input("How old are you in years? "))
months = age*12
days = age*365

print("You are around " + str(months) + " months old.")
print("You are around " + str(days) + " days old.")

input("\nPress ENTER to exit program")
