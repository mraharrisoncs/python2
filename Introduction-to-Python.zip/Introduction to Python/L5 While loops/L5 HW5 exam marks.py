#Program name: L5 HW5 exam marks.py
#Program find maximum, minimum and average exam mark

total = 0
mark = int(input("Enter first exam mark: "))
maxMark = mark
minMark = mark
numberOfMarks = 0

while mark != -1:
    total = total + mark
    if mark < minMark:
        minMark = mark
    if mark > maxMark:
        maxMark = mark
    mark = int(input("Enter next exam mark, -1 to end: "))
    numberOfMarks = numberOfMarks + 1

averageMark = round(total/numberOfMarks)
print ("Maximum mark =",maxMark)
print ("Minimum mark =",minMark)
print("Average mark =",averageMark)

input("Press Enter to exit ")

    
