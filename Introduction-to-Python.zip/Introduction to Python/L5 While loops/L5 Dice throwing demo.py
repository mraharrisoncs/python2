#L5 Dice throwing demo.py

#Import the random number module
import random

print("This program simulates throwing a die.")
print ("Keep throwing until you throw a six.")
print("How many throws will it take??")
# generate a random "throw" between 1 and 10
throw = random.randint(1, 6)
count = 1
print ("You threw",throw)

#Check if a six was thrown
while throw != 6:
    input("No good - press Enter to throw again... ")
    throw = random.randint(1, 6)
    print ("You threw",throw)
    count += 1   #a short way or writing count = count + 1
print("That took "+ str(count) +" throws")
