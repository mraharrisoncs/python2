#Program name: L5 Running total.py

print("Keeping a running total")
print("***********************\n")
print("Enter numbers to add together then press 0 to exit.")

#Initialise the variables
count = 0
runningTotal = 0
number = int(input("Input the first number: "))

#Add each number together until 0 is entered
while number != 0:
    count = count + 1
    runningTotal = runningTotal + number
    number = int(input("Input next number: "))

#Display the total sum and the number of entries made
print ("You entered ",count," numbers")
print ("Total = ",runningTotal)

input("Press ENTER to exit")
