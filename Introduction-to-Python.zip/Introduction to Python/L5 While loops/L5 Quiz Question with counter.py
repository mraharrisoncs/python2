#L5 Quiz Question with counter.py

answer = input("What is the capital of France? ")
answer = answer.title()  #A method to change answer to Title case
counter = 1
while answer != "Paris":
    answer = input("Incorrect, try again: ")
    answer = answer.title()
    counter = counter + 1
print("Correct! You had",counter,"attempts")

input("\n\nPress ENTER to exit")
