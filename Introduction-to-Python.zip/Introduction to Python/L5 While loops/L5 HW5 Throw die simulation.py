#Program L5 HW5 Qu 2 Throw die simulation.py

import random

print("This program simulates a die being thrown 6000 times\n")
count6 = 0
numberOfThrows = 0
while numberOfThrows < 6000:
    throw = random.randint(1,6)
    numberOfThrows = numberOfThrows + 1
#    print(numberOfThrows)
    if throw == 6:
        count6 = count6 + 1
#        print("thrown:", throw)
print("Number of sixes",count6)
    
