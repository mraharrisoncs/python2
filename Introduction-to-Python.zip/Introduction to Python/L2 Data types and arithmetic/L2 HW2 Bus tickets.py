#L2 HW2 Bus tickets.py
passengers = int(input("Enter number of bus passengers: "))
price = float(input("Enter price of one bus ticket: "))
cost = passengers * price
print("Total cost = £" + str(cost))
moneyOffered = float(input("Enter amount offered in £: "))
change = moneyOffered - cost
print("Change from £" + str(moneyOffered) +" = £" +  str(change))

              
