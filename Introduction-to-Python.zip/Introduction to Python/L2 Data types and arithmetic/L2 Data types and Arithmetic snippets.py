#L2 Data types and arithmetic snippets.py

age = int(input("Enter your age "))
print(age)
shoe_size  = float(input("Enter your shoe size "))
print(shoe_size)
price = float(input("Enter the price, without the pounds sign "))
print(price)
postcode  = input("Enter your postcode ")
print(postcode)
height  = float(input("What is your height in metres, eg enter 1.5 for 1.5m "))
print(height)

#The program will crash if you enter a number with a decimal point,
#or enter a non-numeric character
qty  = int(input("Enter the quantity in stock "))
print(qty)
telNo= input("What is your phone number ")
print(telNo)


# numeric values are always input as strings in Python
#If they are to be used in calculations,they must be converted
#to integer or decimal numbers using int() or float()

first_number = input("Enter first number ")
second_number = input("Enter second number ")
print("Without conversion, sum =", first_number + second_number)


first_number = int(input("Enter first number "))
second_number = int(input("Enter second number "))
print("After converting numbers to integers, sum =",
      first_number + second_number)

first_number = float(input("Enter first number "))
second_number = float(input("Enter second number "))
print("After converting numbers to floating point numbers, sum =",
      first_number + second_number)
