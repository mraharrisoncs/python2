#L2 Sleep calculator.py


#Display title for program
print("Welcome to the Sleep Calculator")
print("*******************************")

#Add blank line before input using \n
print ("\n")

#input name
name = input("Please enter your name: ")

#input number of hours asleep per night
hourspernight = input("Hello " + name + ". How many hours per night do you sleep? ")

#arithmetic
hoursperweek = float(hourspernight) * 7
hourspermonth = hoursperweek * 4.35
dayspermonth = hourspermonth / 24

#rounding
dayspermonth = round(dayspermonth)
hourspermonth = round(hourspermonth,2)

#output
print ("\nYou sleep",hoursperweek,"hours per week")
print ("You sleep",hourspermonth,"hours per month")
print ("This equates to roughly",dayspermonth,"days per month")

#Holds the screen until ENTER pressed to read results if using windows console
input("\nPress ENTER to exit program")
