#L3 AdultChild.py

age = int(input("Enter age: "))
if age >= 18:
    print ("Adult")
else:
    print("Child")
