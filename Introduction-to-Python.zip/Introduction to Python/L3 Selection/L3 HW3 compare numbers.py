#L3 HW3 compare numbers.py

num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
if num1 > num2:
    print("The larger number is:",num1)
elif num2 > num1:
    print("The larger number is:",num2)
else:
    print("The two numbers are both equal to",num1)

            
