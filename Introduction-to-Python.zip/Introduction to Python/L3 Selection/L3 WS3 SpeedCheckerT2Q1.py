#Speeding Program worksheet 3, Task 2 question 1
#
speed = int(input("Enter driver's speed: "))
if speed >= 75:
    print("Issue speeding fine")
else:
    print("No action")


