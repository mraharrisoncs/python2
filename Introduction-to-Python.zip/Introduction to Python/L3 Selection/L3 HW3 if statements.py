#L3 HW3 if statements.py
# input lines added where needed
#question 1
#
response = input("enter response: ")
if response == "bleep" :
    print("cycle finished")
#
#question 2
#
mark = int(input("enter mark: "))
if mark > 50 :
    print("pass!")
#
#question 3
#
paper =  input("enter paper: ")
if paper == "n":
    print("load paper before continuing")
#question 4
#
qty = int(input("how many items in stock? "))
if qty <  0 :
    print("that can't be right")
elif qty > 30:
 print("that's plenty, no need to reorder")
else:
   print("order some more")
#question 5
#
light = input("What colour is the traffic light, R, A R/A or G?")
if light == "R":
    print("stop the car")
elif light == "A":
    print("get ready to go")
elif light == "R/A":
    print("prepare to stop")
elif light == "G":
    print("keep going")
else:
    print("invalid input")  


