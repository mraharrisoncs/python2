#Password Checker

print("Welcome to PGO Security Systems")
print("*******************************")

password = input("Enter your password: ")

if password == "abcd1234":
    print("Access Granted")
else:
    print("Access Denied")

input("Press ENTER to exit the program")
