#Speeding Program Task 2 EXTension Activity
##
# check speed is reasonable
speed = int(input("Enter driver's speed: "))
if speed <= 5:
    print("check value entered is correct")
# check speed 
else:
    if speed >= 75:
        print("Issue speeding fine")
    elif speed > 60:
        print("Issue warning")
    else:
        print("No action")
