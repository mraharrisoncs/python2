#Speeding Program EXTENDED worksheet 3 task 2 question 2

speed = int(input("Enter driver's speed: "))
if speed >= 75:
    print("Issue speeding fine")
elif speed >= 60:
    print("Issue warning")
else:
    print("No action")
