#L3 WS3 Join Club.py
age = int(input("please enter your age "))
if age >= 14 :
    print("welcome to the Club")
else:
    print("Sorry, you're not old enough to join yet")

