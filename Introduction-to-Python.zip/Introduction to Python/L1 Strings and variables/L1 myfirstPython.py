# MyfirstPython.py

print ("What is your name?")
firstname = input()
print ("Hello,",firstname)
