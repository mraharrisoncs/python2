#L1 HW1 Question 6.py

print("Please enter your first name: ")
firstname = input()
print("Please enter your favourite food: ")
food = input()
firstname = firstname.upper()
#or you could use a new variable name to store the uppercase version, e.g.
#fnUpperCase = firstname.upper()

food = food.upper()
print(firstname + " LIKES " + food)

# or alternatively you could write:
# print(firstname, "LIKES", food)
#as a space is left automatically between items separated by commas

numChars = len(firstname + " LIKES " + food)
print("The sentence contains",numChars, "characters")


