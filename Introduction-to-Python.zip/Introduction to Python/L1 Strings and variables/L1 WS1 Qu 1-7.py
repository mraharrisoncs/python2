#L1 WS1 Qu 1-7.py

#Question 1
print ("\nQuestion 1")
print ("What is your first name? ")
firstname = input()
print ("Hello,",firstname)
print ("What is your surname? ")
surname = input()
print ("Your surname is ",surname)

#Question 2
print ("\nQuestion 2")
print ("Hello,",firstname,surname)

#Question 3
print ("\nQuestion 3")
print("Your initials are: ",firstname[0],surname[0])

#Question 4
print ("\nQuestion 4")
fullname = firstname +" "+ surname
print(fullname)

#Question 5
print ("\nQuestion 5")
print(surname.upper(), firstname)

#Question 6
print ("\nQuestion 6")
print("Length of surname:",len(surname))

#Question 7
print ("\nQuestion 7")
surname = surname.lower()
firstname = firstname.lower()
username = surname[0]+surname[1]+surname[2]+firstname[0]+str(len(surname))
print("Username: ",username)


