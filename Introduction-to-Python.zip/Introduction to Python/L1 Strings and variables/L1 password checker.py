#L1 Password Checker.py

print("Welcome to PGO Security Systems")
print("*******************************")

password = input("Enter your password:  " )

if password == "abcd1234":
    print("Access Granted")
else:
    print("Access Denied")

input("Press ENTER to exit program")

    

