# DiceRolls.py

import random

print("This program simulates a die being thrown until a 6 is thrown\n")
throw = 0
numberOfThrows = 0
while throw != 6:
    throw = random.randint(1,6)
    numberOfThrows = numberOfThrows + 1
    print("Number thrown: ",throw)
    
print("Number of throws",numberOfThrows)
