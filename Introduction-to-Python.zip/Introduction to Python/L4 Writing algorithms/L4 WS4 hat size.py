#L4 WS4 hat size

size = int (input("what is the circumference of your head in cms? "))

if size < 57 :
    print (" your hat size is small")
elif size > 60 :
    print (" your hat size is large")
else:
    print (" your hat size is medium")	

