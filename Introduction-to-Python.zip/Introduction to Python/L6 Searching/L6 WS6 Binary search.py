#Program name: L6 WS6 binary search.py
#
# initialise number of guesses 
searches = 0
print(" Demo of a binary search")
print(" *******************************")
maximum = int(input("enter the highest number in the range "))
# could prompt for minimum as well, but assumes starts at 1
minimum = 1
# prompt for number to be found from range
number = int(input("Enter the number to find "))
# midpoint is the starting point for search
midpoint = int((maximum+minimum)/2)
while   number != midpoint :
    print("maximum no is ",maximum,  " mimimum is ", minimum)
    print("value examined ",midpoint,"\n")
    # increment number of searches   
    searches += 1
    # adjust maximum or minimum and find the midpoint of the new range
    if number < midpoint :
        maximum = midpoint - 1
    else:
        minimum = midpoint + 1
    # set new midpoint          
    midpoint = int((maximum+minimum)/2)
# exit loop as number has been found
searches += 1
print("maximum no is ",maximum,  " mimimum is ", minimum)
print ("\n",midpoint,"has been found  ",  " number of items examined: ", searches) 


              
              
        
            
